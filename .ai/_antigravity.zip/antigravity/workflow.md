# Antigravity Workflow

1. Read TODO.md
2. Focus ONLY TODO-gravity.md
3. For each task:
   - Clarify goal
   - Define acceptance criteria
   - Define constraints
4. Generate task spec for:
   - Claude (analysis / code proposal)
   - Vitcup (implementation)
5. Review results
6. Escalate to SA if ambiguity exists
