import fs from "fs/promises";
import path from "path";
import { NomicEmbeddingService } from "../src/memory/embedding";
import { SimpleVectorStore } from "../src/memory/vectorStore";
import { MemoryItem } from "../src/memory/types";
// import { v4 as uuidv4 } from 'uuid'; // Use local function instead

// Configuration
const WORKSPACE_ROOT = path.resolve(__dirname, "../../workspace-storage/data/users");
const MEMORY_FILE = path.resolve(__dirname, "../data/memory.json");

async function main() {
    console.log("🚀 Starting Workspace Indexing...");
    
    // Initialize Services
    const embeddingService = new NomicEmbeddingService();
    const vectorStore = new SimpleVectorStore(MEMORY_FILE);
    
    await vectorStore.load(); // Load existing
    
    // Scan Users
    try {
        const users = await fs.readdir(WORKSPACE_ROOT);
        
        for (const userId of users) {
             const userDocDir = path.join(WORKSPACE_ROOT, userId, "documents");
             
             // Check if documents dir exists
             try {
                 await fs.access(userDocDir);
             } catch {
                 continue; // Skip if no documents folder
             }

             const files = await fs.readdir(userDocDir);
             
             for (const file of files) {
                 if (!file.endsWith(".txt") && !file.endsWith(".md")) continue;
                 
                 console.log(`Processing User ${userId} File: ${file}`);
                 const filePath = path.join(userDocDir, file);
                 const content = await fs.readFile(filePath, "utf-8");
                 
                 // Simple Chunking (Paragraphs)
                 const chunks = content.split(/\n\s*\n/).filter(c => c.trim().length > 0);
                 
                 for (const chunk of chunks) {
                     // Check if already indexed (simple content check)
                     // In real app, check hash or metadata
                     const existing = await vectorStore.searchByKeyword(chunk, 1);
                     if (existing.length > 0 && existing[0].content === chunk) {
                        // console.log("   - Skipping duplicate chunk");
                         continue;
                     }
                     
                     // Generate Embedding
                     const embedding = await embeddingService.embed(chunk);
                     
                     if (embedding) {
                        // Add to Store
                        const item: MemoryItem = {
                            id: uuidv4(),
                            content: chunk,
                            type: "file",
                            metadata: {
                                userId,
                                filename: file,
                                filePath
                            },
                            embedding,
                            timestamp: Date.now()
                        };
                        await vectorStore.add(item);
                        console.log(`   + Indexed chunk (${chunk.length} chars)`);
                     } else {
                         console.warn("   ! Embedding failed (Ollama down?), skipping chunk");
                     }
                 }
             }
        }
        
        // Save
        await vectorStore.save();
        console.log("✅ Indexing Complete.");
        
    } catch (err) {
        console.error("Indexing Error:", err);
    }
}

// Simple UUID generator if uuid package missing
function uuidv4() {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
}

main();
