/**
 * Phase 4: Speed Benchmark & Contract Test
 *
 * RUN: npx tsx --test tests/speed/benchmark.spec.ts
 */

import test, { describe } from "node:test";
import assert from "node:assert/strict";
import { flashSelector } from "../../src/intelligence/flashSelector";
import { IntelligencePipeline } from "../../src/intelligence/pipeline";

// Mock tools for pipeline testing
const MOCK_TOOLS = {
    "nwp_daily_by_place": {
        execute: async (args: any) => {
            await new Promise(r => setTimeout(r, 100)); // Simulate 100ms API work
            return { content: [{ type: "text", text: `Weather in ${args.province}` }] };
        }
    },
    "calculatorTool": {
        execute: async (args: any) => {
            return { content: [{ type: "text", text: "42" }] };
        }
    }
};

describe("Phase 4: Speed Contract", () => {

    test("SLA: Selection time < 200ms", async () => {
        const start = performance.now();
        const result = flashSelector.select("พยากรณ์อากาศที่เชียงใหม่");
        const end = performance.now();
        const latency = end - start;
        
        console.log(`[Benchmark] Selection Latency: ${latency.toFixed(2)}ms`);
        assert.ok(latency < 200, `Selection took ${latency}ms (Max 200ms)`);
        
        // Assert Correctness
        assert.ok(result, "Should match Thai weather query");
        assert.equal(result?.toolName, "nwp_daily_by_place");
        assert.equal(result?.args.province, "เชียงใหม่"); // Extracted from query? or mapped? 
        // Our impl currently maps specific known provinces. check impl. 
        // Logic: "foundProvince" -> returns that. 
        // "เชียงใหม่" matches "เชียงใหม่" in known list.
    });

    test("SLA: Math Selection < 5ms", async () => {
        const start = performance.now();
        const result = flashSelector.select("1 + 1");
        const end = performance.now();
        const latency = end - start;
        console.log(`[Benchmark] Math Latency: ${latency.toFixed(2)}ms`);
        
        assert.equal(result?.toolName, "calculatorTool");
    });

    test("Pipeline: End-to-End Latency < 1.5s (Mocked Tool)", async () => {
        const pipeline = new IntelligencePipeline(MOCK_TOOLS);
        const start = performance.now();
        
        let firstByteTime = 0;
        
        // Wrap event emission in promise
        await new Promise<void>((resolve) => {
            pipeline.on("event", (e) => {
                if (e.type === "tool_result") {
                    firstByteTime = e.timestamp;
                    resolve();
                }
            });
            pipeline.execute("พยากรณ์อากาศที่เชียงใหม่");
        });
        
        console.log(`[Benchmark] TTFB: ${firstByteTime.toFixed(2)}ms`);
        assert.ok(firstByteTime < 1500, "TTFB should be < 1.5s");
    });
});
