
import axios from 'axios';

async function main() {
    try {
        console.log("Testing /api/smart endpoint...");
        const response = await axios.post('http://localhost:3012/api/smart', {
            query: 'พยากรณ์อากาศที่เชียงใหม่' 
        }, {
            responseType: 'stream'
        });

        response.data.on('data', (chunk: Buffer) => {
            const lines = chunk.toString().split('\n');
            for (const line of lines) {
                if (line.startsWith('data: ')) {
                    const data = line.slice(6);
                    if (data === '[DONE]') {
                        console.log("Stream Complete");
                    } else {
                        try {
                           const event = JSON.parse(data);
                           console.log("Received Event:", event.type, event.payload);
                        } catch (e) {
                            console.log("Raw Data:", data);
                        }
                    }
                }
            }
        });

        response.data.on('end', () => {
             console.log("Test Passed ✅");
        });

    } catch (error: any) {
        if (error.response) {
             console.error(`Error Status: ${error.response.status} ${error.response.statusText}`);
             // Try to read stream if possible, or just log safely
             if (error.response.data && typeof error.response.data.read === 'function') {
                 error.response.data.on('data', (d: any) => console.error("Error Body:", d.toString()));
             } else {
                 console.error("Error Response Data:", error.response.data);
             }
        } else {
            console.error("Error:", error.message);
        }
    }
}

main();
