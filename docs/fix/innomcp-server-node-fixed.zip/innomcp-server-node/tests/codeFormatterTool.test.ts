import { describe, test, expect } from "@jest/globals";
import codeFormatterTool from "../src/mcp/tools/codeFormatterTool";

describe("codeFormatterTool", () => {
  
  test("should format messy JavaScript code", async () => {
    const messyCode = `function hello(){console.log('hi');return true;}`;
    
    const result = await codeFormatterTool.execute({
      code: messyCode,
      language: "javascript"
    });

    expect(result.success).toBe(true);
    expect(result.language).toBe("javascript");
    expect(result.formattedCode).toContain("function hello()");
    expect(result.formattedCode).toContain("console.log");
    expect(result.formattedCode).not.toBe(messyCode); // Should be different
  });

  test("should format TypeScript code", async () => {
    const tsCode = `interface User{name:string;age:number}const user:User={name:'John',age:30};`;
    
    const result = await codeFormatterTool.execute({
      code: tsCode,
      language: "typescript"
    });

    expect(result.success).toBe(true);
    expect(result.language).toBe("typescript");
    expect(result.formattedCode).toContain("interface User");
    expect(result.formattedCode).toContain("name: string");
  });

  test("should format JSON", async () => {
    const messyJson = `{"name":"John","age":30,"city":"Bangkok"}`;
    
    const result = await codeFormatterTool.execute({
      code: messyJson,
      language: "json"
    });

    expect(result.success).toBe(true);
    expect(result.formattedCode).toContain('"name"');
    expect(result.formattedCode).toContain('"John"');
    expect(result.linesAfter).toBeGreaterThan(result.linesBefore);
  });

  test("should format CSS", async () => {
    const messyCSS = `.container{display:flex;margin:0;padding:10px;}`;
    
    const result = await codeFormatterTool.execute({
      code: messyCSS,
      language: "css"
    });

    expect(result.success).toBe(true);
    expect(result.formattedCode).toContain(".container");
    expect(result.formattedCode).toContain("display: flex");
  });

  test("should format HTML", async () => {
    const messyHTML = `<div><p>Hello</p><span>World</span></div>`;
    
    const result = await codeFormatterTool.execute({
      code: messyHTML,
      language: "html"
    });

    expect(result.success).toBe(true);
    expect(result.formattedCode).toContain("<div>");
    expect(result.formattedCode).toContain("<p>Hello</p>");
  });

  test("should handle empty code", async () => {
    const result = await codeFormatterTool.execute({
      code: "",
      language: "javascript"
    });

    expect(result.success).toBe(false);
    expect(result.error).toContain("กรุณาระบุโค้ด");
  });

  test("should handle whitespace-only code", async () => {
    const result = await codeFormatterTool.execute({
      code: "   \n   ",
      language: "javascript"
    });

    expect(result.success).toBe(false);
    expect(result.error).toContain("กรุณาระบุโค้ด");
  });

  test("should handle unsupported language", async () => {
    const result = await codeFormatterTool.execute({
      code: "some code",
      language: "cobol"
    });

    expect(result.success).toBe(false);
    expect(result.error).toContain("ไม่รองรับภาษา");
  });

  test("should respect custom tabWidth", async () => {
    const code = `function test(){return 42;}`;
    
    const result = await codeFormatterTool.execute({
      code,
      language: "javascript",
      tabWidth: 4
    });

    expect(result.success).toBe(true);
    // Check for 4-space indentation
    expect(result.formattedCode).toContain("    "); // 4 spaces
  });

  test("should respect singleQuote option", async () => {
    const code = `const msg = "hello";`;
    
    const result = await codeFormatterTool.execute({
      code,
      language: "javascript",
      singleQuote: true
    });

    expect(result.success).toBe(true);
    expect(result.formattedCode).toContain("'hello'"); // Single quotes
  });

  test("should handle syntax errors gracefully", async () => {
    const invalidCode = `function test((({{`;
    
    const result = await codeFormatterTool.execute({
      code: invalidCode,
      language: "javascript"
    });

    expect(result.success).toBe(false);
    expect(result.error).toBeDefined();
    expect(result.formattedCode).toBe(invalidCode); // Return original
  });

  test("should count lines correctly", async () => {
    const code = `function test(){return true;}`;
    
    const result = await codeFormatterTool.execute({
      code,
      language: "javascript"
    });

    expect(result.success).toBe(true);
    expect(result.linesBefore).toBe(1);
    expect(result.linesAfter).toBeGreaterThan(1); // Expanded to multiple lines
  });

  test("should format Markdown", async () => {
    const messyMD = `#  Title\n\n\n\nSome text  `;
    
    const result = await codeFormatterTool.execute({
      code: messyMD,
      language: "markdown"
    });

    expect(result.success).toBe(true);
    expect(result.formattedCode).toContain("# Title");
  });

  test("should format YAML", async () => {
    const messyYAML = `name:  John\nage:30\ncity:    Bangkok`;
    
    const result = await codeFormatterTool.execute({
      code: messyYAML,
      language: "yaml"
    });

    expect(result.success).toBe(true);
    expect(result.formattedCode).toContain("name:");
    expect(result.formattedCode).toContain("age:");
  });

  test("should handle very long code (up to 50000 chars)", async () => {
    const longCode = `const arr = [${Array(5000).fill("1").join(",")}];`;
    
    const result = await codeFormatterTool.execute({
      code: longCode,
      language: "javascript"
    });

    expect(result.success).toBe(true);
    expect(result.formattedCode.length).toBeGreaterThan(0);
  });

  test("should reject code longer than 50000 chars", async () => {
    const tooLongCode = "x".repeat(50001);
    
    const result = await codeFormatterTool.execute({
      code: tooLongCode,
      language: "javascript"
    });

    expect(result.success).toBe(false);
    expect(result.error).toContain("ยาวเกินไป");
  });

  test("should normalize language names", async () => {
    const code = `function test(){}`;
    
    // Test "js" alias
    const result1 = await codeFormatterTool.execute({
      code,
      language: "js"
    });
    expect(result1.success).toBe(true);
    expect(result1.language).toBe("js");

    // Test "ts" alias
    const result2 = await codeFormatterTool.execute({
      code,
      language: "ts"
    });
    expect(result2.success).toBe(true);
    expect(result2.language).toBe("ts");
  });
});
