/**
 * Test All MCP Tools
 * Run: npx ts-node tests/test-all-tools.ts
 */

interface ToolTest {
  name: string;
  args: any;
  expectedPattern?: RegExp;
  maxDuration?: number; // ms
}

const MCP_SERVER_URL =
  process.env.MCP_SERVER_URL ||
  (process.env.SERVER_PORT ? `http://localhost:${process.env.SERVER_PORT}/mcp` : "http://localhost:3013/mcp");

async function callTool(toolName: string, args: any): Promise<any> {
  const startTime = Date.now();
  
  try {
    const response = await fetch(MCP_SERVER_URL, {
      method: "POST",
      headers: { 
        "Content-Type": "application/json",
        "Accept": "application/json, text/event-stream"
      },
      body: JSON.stringify({
        jsonrpc: "2.0",
        method: "tools/call",
        params: {
          name: toolName,
          arguments: args
        },
        id: Date.now()
      })
    });

    const duration = Date.now() - startTime;
    const result = await response.json();
    return { result, duration, success: response.ok };
  } catch (error) {
    const duration = Date.now() - startTime;
    // Use logBoth for error logging
    try {
      const { logBoth } = await import('../src/utils/mcpLogger');
      logBoth('ERROR', `[TestAllTools] Error calling tool '${toolName}': ${error instanceof Error ? error.message : String(error)}`);
    } catch {}
    return { error: error instanceof Error ? error.message : String(error), duration, success: false };
  }
}

const TOOL_TESTS: ToolTest[] = [
  // 1. DateTime Tool
  {
    name: "dateTimeTool",
    args: { format: "full" },
    expectedPattern: /\d{1,2}|มกราคม|กุมภาพันธ์|มีนาคม|เมษายน|พฤษภาคม|มิถุนายน|กรกฎาคม|สิงหาคม|กันยายน|ตุลาคม|พฤศจิกายน|ธันวาคม|\d{4}/i,
    maxDuration: 100
  },
  
  // 2. Calculator Tool (Enhanced MathTool)
  {
    name: "calculatorTool",
    args: { expression: "321+1233333" },
    expectedPattern: /1233654/,
    maxDuration: 100
  },
  {
    name: "calculatorTool",
    args: { expression: "mean([2,4,6,8,10])" },
    expectedPattern: /6/,
    maxDuration: 100
  },
  
  // 3. Newton Tool (Symbolic Math)
  {
    name: "newton",
    args: { operation: "derive", expression: "x^2+3x" },
    expectedPattern: /2\s*x\s*\+\s*3/,
    maxDuration: 2000  // Increased from 1500ms - newton API is slow
  },
  {
    name: "newton",
    args: { operation: "simplify", expression: "x^2+2x+1" },
    expectedPattern: /simplify/i,
    maxDuration: 1500
  },
  
  // 4. Archive Tool
  {
    name: "archive",
    args: { query: "artificial intelligence", rows: 5 },
    expectedPattern: /items|docs|mediatype|collection|internet archive/i,
    maxDuration: 3000
  },
  
  // 5. NASA Tool
  {
    name: "nasa",
    args: { endpoint: "apod" },
    expectedPattern: /title|explanation|url/i,
    maxDuration: 2500
  },
  
  // 6. Weather Tool (will fail without API key)
  {
    name: "weather",
    args: { city: "Bangkok", type: "current" },
    expectedPattern: /temperature|API key|error/i,
    maxDuration: 3000
  },
  
  // 7. World Bank Tool
  {
    name: "worldbank",
    args: { country: "TH", indicator: "GDP" },
    expectedPattern: /GDP|value|Thailand/i,
    maxDuration: 4000
  },
  
  // 8. GovData Tool
  {
    name: "govdata",
    args: { query: "census", rows: 5 },
    expectedPattern: /title|organization|dataset/i,
    maxDuration: 4000
  },
  // 9. Echarts Tool (SVG chart generation)
  {
    name: "echartsTool",
    args: { type: "bar", labels: ["A", "B", "C"], datasets: [{ label: "Demo", data: [10, 20, 30] }], chartTitle: "Demo Chart" },
    expectedPattern: /กราฟถูกสร้างขึ้น|svg|chartSvg/i,
    maxDuration: 4000
  },
  // 10. TMD Tools (test one endpoint, e.g., tmd_weather_today_07am_all_stations)
  {
    name: "tmd_weather_today_07am_all_stations",
    args: {},
    expectedPattern: /Stations|WmoStationNumber|LastUpdate|Temperature|result|content/i,
    maxDuration: 20000  // TMD ช้า ให้เวลา 20 วิ
  },
  // 11. Webd Tools (test group, platforms, register_country)
  {
    name: "webdTool_group",
    args: { query: "hate" },
    expectedPattern: /group_name|url_count|data|success/i,
    maxDuration: 4000
  },
  {
    name: "webdTool_platforms",
    args: {},
    expectedPattern: /platform|url_count|percentage|data|success/i,
    maxDuration: 4000
  },
  {
    name: "webdTool_register_country",
    args: {},
    expectedPattern: /country|url_count|percentage|data|success/i,
    maxDuration: 4000
  }
];

async function runTests() {
  console.log("🧪 ========================================");
  console.log("🧪 MCP TOOLS TEST SUITE");
  console.log("🧪 ========================================\n");
  console.log(`📡 Server: ${MCP_SERVER_URL}\n`);

  let passed = 0;
  let failed = 0;
  const results: any[] = [];

  for (const test of TOOL_TESTS) {
    console.log(`\n🔧 Testing: ${test.name}`);
    console.log(`   Args: ${JSON.stringify(test.args).substring(0, 60)}...`);
    
    // Dependency-aware/skippable tests for tools that require backend/API keys
    let skip = false;
    if (["weather"].includes(test.name)) {
      if (!process.env.OPENWEATHER_API_KEY) {
        console.log(`   ⚠️  SKIPPED: Missing OPENWEATHER_API_KEY`);
        skip = true;
      }
    }
    if (["webdTool_group", "webdTool_platforms", "webdTool_register_country"].includes(test.name)) {
      if (!process.env.WEBDDSB_APIKEY) {
        console.log(`   ⚠️  SKIPPED: Missing WEBDDSB_APIKEY`);
        skip = true;
      }
    }
    if (skip) {
      results.push({ tool: test.name, passed: null, duration: 0, reason: "SKIPPED" });
      continue;
    }
    const { result, duration, success, error } = await callTool(test.name, test.args);
    
    // Check success
    let testPassed = success;
    let reason = "";

    if (!success) {
      reason = error || "HTTP request failed";
      testPassed = false;
    } else if (result.error) {
      reason = `MCP Error: ${JSON.stringify(result.error)}`;
      testPassed = false;
    } else {
      // Check duration
      if (test.maxDuration && duration > test.maxDuration) {
        reason = `Too slow: ${duration}ms > ${test.maxDuration}ms`;
        testPassed = false;
      }
      
      // Check pattern
      if (test.expectedPattern) {
        const content = JSON.stringify(result.result?.content || result);
        if (!test.expectedPattern.test(content)) {
          reason = `Pattern not matched: ${test.expectedPattern}`;
          testPassed = false;
        }
      }
    }

    if (testPassed) {
      console.log(`   ✅ PASS (${duration}ms)`);
      passed++;
    } else {
      console.log(`   ❌ FAIL (${duration}ms)`);
      console.log(`   Reason: ${reason}`);
      failed++;
    }
    results.push({
      tool: test.name,
      passed: testPassed,
      duration,
      reason
    });
  }

  // Summary
  console.log("\n\n📊 ========================================");
  console.log("📊 TEST SUMMARY");
  console.log("📊 ========================================");
  console.log(`✅ Passed: ${passed}/${TOOL_TESTS.length}`);
  console.log(`❌ Failed: ${failed}/${TOOL_TESTS.length}`);  console.log(`⏭️  Skipped: ${results.filter(r => r.passed === null).length}/${TOOL_TESTS.length}`);  console.log(`📈 Success Rate: ${((passed / TOOL_TESTS.length) * 100).toFixed(1)}%\n`);

  // Failed tests detail
  if (failed > 0) {
    console.log("❌ Failed Tests:");
    results.filter(r => !r.passed).forEach(r => {
      console.log(`   - ${r.tool}: ${r.reason}`);
    });
  }

  console.log("\n");
  process.exit(failed > 0 ? 1 : 0);
}

// Run tests
runTests().catch(err => {
  console.error("💥 Test suite crashed:", err);
  process.exit(1);
});
