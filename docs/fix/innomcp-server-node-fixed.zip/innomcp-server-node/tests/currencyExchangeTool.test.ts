import { describe, test, expect } from "@jest/globals";
import currencyExchangeTool from "../src/mcp/tools/currencyExchangeTool";

describe("currencyExchangeTool", () => {
  
  test("should convert USD to THB", async () => {
    const result = await currencyExchangeTool.execute({
      amount: 100,
      fromCurrency: "USD",
      toCurrency: "THB"
    });

    expect(result.content).toBeDefined();
    expect(result.content[0].type).toBe("text");
    
    const data = JSON.parse(result.content[0].text);
    expect(data.success).toBe(true);
    expect(data.fromCurrency).toBe("USD");
    expect(data.toCurrency).toBe("THB");
    expect(data.amount).toBe(100);
    expect(data.convertedAmount).toBeGreaterThan(0);
    expect(data.exchangeRate).toBeGreaterThan(0);
    expect(data.timestamp).toBeDefined();
  }, 10000);

  test("should convert EUR to JPY", async () => {
    const result = await currencyExchangeTool.execute({
      amount: 50,
      fromCurrency: "EUR",
      toCurrency: "JPY"
    });

    const data = JSON.parse(result.content[0].text);
    expect(data.success).toBe(true);
    expect(data.fromCurrency).toBe("EUR");
    expect(data.toCurrency).toBe("JPY");
    expect(data.convertedAmount).toBeGreaterThan(0);
  }, 10000);

  test("should handle invalid amount (zero)", async () => {
    const result = await currencyExchangeTool.execute({
      amount: 0,
      fromCurrency: "USD",
      toCurrency: "THB"
    });

    const data = JSON.parse(result.content[0].text);
    expect(data.success).toBe(false);
    expect(data.error).toContain("มากกว่า 0");
  });

  test("should handle invalid amount (negative)", async () => {
    const result = await currencyExchangeTool.execute({
      amount: -100,
      fromCurrency: "USD",
      toCurrency: "THB"
    });

    const data = JSON.parse(result.content[0].text);
    expect(data.success).toBe(false);
    expect(data.error).toContain("มากกว่า 0");
  });

  test("should handle invalid currency code", async () => {
    const result = await currencyExchangeTool.execute({
      amount: 100,
      fromCurrency: "INVALID",
    const data = JSON.parse(result.content[0].text);
    expect(data.success).toBe(false);
  }, 10000);

  test("should convert THB to USD", async () => {
    const result = await currencyExchangeTool.execute({
      amount: 1000,
      fromCurrency: "THB",
      toCurrency: "USD"
    });

    const data = JSON.parse(result.content[0].text);
    expect(data.success).toBe(true);
    expect(data.convertedAmount).toBeGreaterThan(0);
    expect(data.convertedAmount).toBeLessThan(1000);
  }, 10000);

  test("should normalize currency codes (lowercase input)", async () => {
    const result = await currencyExchangeTool.execute({
      amount: 100,
      fromCurrency: "usd",
      toCurrency: "thb"
    });

    const data = JSON.parse(result.content[0].text);
    expect(data.success).toBe(true);
    expect(data.fromCurrency).toBe("USD");
    expect(data.toCurrency).toBe("THB");
  }, 10000);

  test("should return exchange rate with 6 decimal places", async () => {
    const result = await currencyExchangeTool.execute({
      amount: 1,
      fromCurrency: "USD",
      toCurrency: "THB"
    });

    const data = JSON.parse(result.content[0].text);
    expect(data.success).toBe(true);
    expect(data.exchangeRate).toBeGreaterThan(0);
    const decimalPlaces = datatrue);
    expect(result.exchangeRate).toBeGreaterThan(0);
    // Check decimal places
    const decimalPlaces = result.exchangeRate.toString().split(".")[1]?.length || 0;
    expect(decimalPlaces).toBeLessThanOrEqual(6);
  }, 10000);
});
