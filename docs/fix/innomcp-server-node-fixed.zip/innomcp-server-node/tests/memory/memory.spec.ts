import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { NomicEmbeddingService } from '../../src/memory/embedding';
import { SimpleVectorStore } from '../../src/memory/vectorStore';
import { MemoryItem } from '../../src/memory/types';
import fs from 'fs/promises';

describe('Memory System', () => {
    
    // 1. Embedding Service
    describe('NomicEmbeddingService', () => {
        const embedService = new NomicEmbeddingService(
            "http://localhost:11434/api/embeddings",
            "nomic-embed-text",
            5000 // 5s timeout for test
        );

        it('should return null if Ollama is down or model missing (Graceful Fallback)', async () => {
            // We assume Ollama might NOT be running in CI/Test env, so this checks graceful fail
            // OR if it IS running, it checks that it returns a vector. 
            // Better to mock fetch? 
            // For now, let's just check it doesn't THROW.
            try {
                const vec = await embedService.embed("Test");
                if (vec) {
                    assert.equal(vec.length, 768);
                    console.log("   -> Ollama is running! Vector received.");
                } else {
                    console.log("   -> Ollama not reachable (or timeout), returning null as expected.");
                }
            } catch (err) {
                assert.fail("Should not throw error");
            }
        });
    });

    // 2. Vector Store
    describe('SimpleVectorStore', () => {
        const store = new SimpleVectorStore("./data/test_memory.json");
        
        const mockItem1: MemoryItem = {
            id: "1",
            content: "Apple is a fruit.",
            type: "file",
            embedding: [1, 0, 0],
            timestamp: Date.now()
        };
        const mockItem2: MemoryItem = {
            id: "2",
            content: "Car is a vehicle.",
            type: "file",
            embedding: [0, 1, 0],
            timestamp: Date.now()
        };

        it('should add items and search by similarity', async () => {
            await store.add(mockItem1);
            await store.add(mockItem2);

            // Query "Fruit" (similar to [1,0,0])
            const results = await store.search([0.9, 0.1, 0], 1);
            assert.equal(results[0].id, "1");
        });

        it('should search by keyword (Fallback)', async () => {
             const results = await store.searchByKeyword("vehicle");
             assert.equal(results[0].id, "2");
        });

        it('should save and load from disk', async () => {
            await store.save();
            
            // New instance
            const store2 = new SimpleVectorStore("./data/test_memory.json");
            await store2.load();
            
            const results = await store2.searchByKeyword("Apple");
            assert.equal(results.length, 1);
            
            // Cleanup
            await fs.unlink("./data/test_memory.json");
        });
    });
});
