import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { thaiReligionTool } from '../../src/mcp/tools/thaiReligionTool';
import { ReligionType } from '../../src/mcp/knowledge/types/religion';

describe('Thai Religion Tool (Contract)', () => {
    
    it('should have correct name and description', () => {
        assert.equal(thaiReligionTool.name, 'thai_religion_tool');
        assert.ok(thaiReligionTool.description.includes('Buddhism'));
    });

    it('should validate input schema', () => {
        const valid = thaiReligionTool.inputSchema.safeParse({
            query: "วัดพระแก้ว",
            type: "place",
            province: "กรุงเทพมหานคร"
        });
        assert.ok(valid.success);
    });

    it('should return real response (Round C)', async () => {
        const result = await thaiReligionTool.execute({ query: "วัดพระแก้ว" });
        assert.ok(!result.content[0].text.includes("[STUB]"));
        assert.ok(result.content[0].text.includes("วัดพระศรีรัตนศาสดาราม"));
    });
    
    it('should support Temple Search by Province (Round C)', async () => {
         const result = await thaiReligionTool.execute({ 
             query: "วัด", 
             type: "place",
             province: "กรุงเทพมหานคร"
         });
         assert.ok(result.content[0].text.includes("วัดพระเชตุพน"));
    });
});
