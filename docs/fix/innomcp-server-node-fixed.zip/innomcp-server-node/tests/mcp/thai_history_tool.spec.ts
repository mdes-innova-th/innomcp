/**
 * Phase 2: Thai History Tool — TDD Test Suite
 *
 * These tests define the CONTRACT for thai_history_tool.
 * Tests marked [SEED REQUIRED] will FAIL until Vitcup populates seed data.
 *
 * Run: npx tsx --test tests/mcp/thai_history_tool.spec.ts
 */
import test, { describe, before, after } from "node:test";
import assert from "node:assert/strict";
import {
  thaiHistoryTool,
  setHistoryDb,
  InMemoryHistoryDb,
  THAI_HISTORY_SEED,
  MariaDbHistoryDb,
  type HistoryDbAdapter,
} from "../../src/mcp/tools/thaiHistoryTool";

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function parseToolText(result: any): any {
  assert.ok(result, "result must be defined");
  assert.ok(Array.isArray(result.content), "result.content must be an array");
  assert.equal(result.content[0]?.type, "text");
  return JSON.parse(result.content[0].text);
}

// ---------------------------------------------------------------------------
// Use InMemory adapter to avoid DB dependency in unit tests
// ---------------------------------------------------------------------------

before(() => {
  setHistoryDb(new InMemoryHistoryDb(THAI_HISTORY_SEED));
});

after(() => {
  setHistoryDb(new MariaDbHistoryDb());
});

// ===========================================================================
// 1. Basic Contract
// ===========================================================================

describe("thai_history_tool: basic contract", () => {
  test("tool name is stable", () => {
    assert.equal(thaiHistoryTool.name, "thai_history_tool");
  });

  test("empty query -> INVALID_QUERY", async () => {
    const result = await thaiHistoryTool.execute({ query: "" });
    const body = parseToolText(result);
    assert.equal(body.success, false);
    assert.equal(body.error_code, "INVALID_QUERY");
  });

  test("whitespace-only query -> INVALID_QUERY", async () => {
    const result = await thaiHistoryTool.execute({ query: "   " });
    const body = parseToolText(result);
    assert.equal(body.success, false);
    assert.equal(body.error_code, "INVALID_QUERY");
  });
});

// ===========================================================================
// 2. Era Lookup (Sukhothai) — should PASS with current seed
// ===========================================================================

describe("thai_history_tool: era lookup", () => {
  test("'สุโขทัย' returns Sukhothai era", async () => {
    const result = await thaiHistoryTool.execute({ query: "สุโขทัย" });
    const body = parseToolText(result);

    assert.equal(body.success, true);
    assert.equal(body.domain, "history");
    assert.ok(Array.isArray(body.data));
    assert.ok(body.data.length >= 1, "should return at least 1 result");

    const first = body.data[0];
    assert.ok(
      first.name_th.includes("สุโขทัย"),
      `name_th should contain สุโขทัย, got: ${first.name_th}`,
    );
    assert.ok(typeof body.confidence === "number");
    assert.ok(body.confidence >= 0.9, `confidence should be >= 0.9, got: ${body.confidence}`);
  });

  test("'สุโขทัย' result has correct era attributes", async () => {
    const result = await thaiHistoryTool.execute({ query: "สุโขทัย" });
    const body = parseToolText(result);
    const attrs = body.data[0].attributes;

    // Current seed uses flat attributes — after migration should have entity_type: "era"
    assert.ok(attrs.year_start === 1249 || attrs.year_start, "year_start should exist");
    assert.ok(attrs.period, "period should exist");
    assert.ok(
      Array.isArray(attrs.key_figures) && attrs.key_figures.length > 0,
      "key_figures should be a non-empty array",
    );
  });

  test("'อยุธยา' returns Ayutthaya era", async () => {
    const result = await thaiHistoryTool.execute({ query: "อยุธยา" });
    const body = parseToolText(result);

    assert.equal(body.success, true);
    assert.ok(body.data[0].name_th.includes("อยุธยา"));
    assert.ok(body.confidence >= 0.9);
  });

  test("'ธนบุรี' returns Thonburi era", async () => {
    const result = await thaiHistoryTool.execute({ query: "ธนบุรี" });
    const body = parseToolText(result);

    assert.equal(body.success, true);
    assert.ok(body.data[0].name_th.includes("ธนบุรี"));
  });

  test("'รัตนโกสินทร์' returns Rattanakosin era", async () => {
    const result = await thaiHistoryTool.execute({ query: "รัตนโกสินทร์" });
    const body = parseToolText(result);

    assert.equal(body.success, true);
    assert.ok(body.data[0].name_th.includes("รัตนโกสินทร์"));
  });
});

// ===========================================================================
// 3. Person Lookup (King Naresuan) — [SEED REQUIRED] will FAIL initially
// ===========================================================================

describe("thai_history_tool: person lookup", () => {
  test("[SEED REQUIRED] 'พระนเรศวร' returns King Naresuan", async () => {
    const result = await thaiHistoryTool.execute({ query: "พระนเรศวร" });
    const body = parseToolText(result);

    assert.equal(body.success, true, "should find King Naresuan");
    assert.ok(body.data.length >= 1);

    const naresuan = body.data[0];
    assert.ok(
      naresuan.name_th.includes("นเรศวร"),
      `name_th should contain นเรศวร, got: ${naresuan.name_th}`,
    );

    // After Phase 2 migration: attributes should have entity_type "person"
    const attrs = naresuan.attributes;
    assert.equal(attrs.entity_type, "person", "should be a person entity");
    assert.equal(attrs.role, "King", "Naresuan was a King");
    assert.ok(attrs.era, "should reference an era");
    assert.ok(attrs.significance, "should describe significance");
  });

  test("[SEED REQUIRED] 'Naresuan' (English alias) also matches", async () => {
    const result = await thaiHistoryTool.execute({ query: "Naresuan" });
    const body = parseToolText(result);

    assert.equal(body.success, true);
    assert.ok(body.data[0].name_th.includes("นเรศวร"));
    assert.ok(body.note?.includes("alias"), "should note alias match");
  });

  test("[SEED REQUIRED] 'พ่อขุนรามคำแหง' returns King Ramkhamhaeng", async () => {
    const result = await thaiHistoryTool.execute({ query: "พ่อขุนรามคำแหง" });
    const body = parseToolText(result);

    assert.equal(body.success, true);
    assert.ok(body.data[0].name_th.includes("รามคำแหง"));

    const attrs = body.data[0].attributes;
    assert.equal(attrs.entity_type, "person");
    assert.ok(attrs.significance.length > 0, "significance should not be empty");
  });

  test("[SEED REQUIRED] 'พระเจ้าตากสิน' returns King Taksin", async () => {
    const result = await thaiHistoryTool.execute({ query: "พระเจ้าตากสิน" });
    const body = parseToolText(result);

    assert.equal(body.success, true);
    assert.ok(body.data[0].name_th.includes("ตากสิน"));

    const attrs = body.data[0].attributes;
    assert.equal(attrs.entity_type, "person");
    assert.equal(attrs.role, "King");
  });

  test("[SEED REQUIRED] 'จุฬาลงกรณ์' returns King Chulalongkorn (Rama V)", async () => {
    const result = await thaiHistoryTool.execute({ query: "จุฬาลงกรณ์" });
    const body = parseToolText(result);

    assert.equal(body.success, true);
    const attrs = body.data[0].attributes;
    assert.equal(attrs.entity_type, "person");
    assert.equal(attrs.role, "King");
  });
});

// ===========================================================================
// 4. Event Lookup — [SEED REQUIRED] will FAIL initially
// ===========================================================================

describe("thai_history_tool: event lookup", () => {
  test("[SEED REQUIRED] 'เสียกรุงครั้งที่ 2' returns Fall of Ayutthaya", async () => {
    const result = await thaiHistoryTool.execute({ query: "เสียกรุงครั้งที่ 2" });
    const body = parseToolText(result);

    assert.equal(body.success, true, "should find the Fall of Ayutthaya event");
    assert.ok(body.data.length >= 1);

    const event = body.data[0];
    const attrs = event.attributes;
    assert.equal(attrs.entity_type, "event", "should be an event entity");
    assert.equal(attrs.year, 1767, "Fall of Ayutthaya 2 occurred in 1767 CE");
    assert.ok(attrs.significance, "should describe significance");
  });

  test("[SEED REQUIRED] 'สนธิสัญญาเบาว์ริง' returns Bowring Treaty", async () => {
    const result = await thaiHistoryTool.execute({ query: "สนธิสัญญาเบาว์ริง" });
    const body = parseToolText(result);

    assert.equal(body.success, true);
    const attrs = body.data[0].attributes;
    assert.equal(attrs.entity_type, "event");
    assert.equal(attrs.event_type, "treaty");
    assert.equal(attrs.year, 1855);
  });

  test("'ปฏิวัติ 2475' returns Siamese Revolution (existing seed)", async () => {
    const result = await thaiHistoryTool.execute({ query: "ปฏิวัติ 2475" });
    const body = parseToolText(result);

    assert.equal(body.success, true);
    assert.ok(body.data[0].name_th.includes("ปฏิวัติ"));
    assert.ok(body.data[0].attributes.year_start === 1932 || body.data[0].attributes.year === 1932);
  });
});

// ===========================================================================
// 5. Unknown / Low-Confidence Query — should PASS
// ===========================================================================

describe("thai_history_tool: unknown queries", () => {
  test("completely unknown query -> NOT_FOUND", async () => {
    const result = await thaiHistoryTool.execute({ query: "xyzzy12345" });
    const body = parseToolText(result);

    assert.equal(body.success, false);
    assert.equal(body.error_code, "NOT_FOUND");
  });

  test("hallucinated history -> NOT_FOUND (anti-hallucination)", async () => {
    // This is not a real Thai historical entity
    const result = await thaiHistoryTool.execute({ query: "อาณาจักรเชียงทอง" });
    const body = parseToolText(result);

    assert.equal(body.success, false, "hallucinated entity should not match");
    assert.equal(body.error_code, "NOT_FOUND");
  });

  test("confidence_required gates low-confidence results", async () => {
    // Partial match should have lower confidence — gate at 0.95 to reject
    const result = await thaiHistoryTool.execute({
      query: "สุโข",
      context: { confidence_required: 0.95 },
    });
    const body = parseToolText(result);

    assert.equal(body.success, false);
    assert.equal(body.error_code, "NOT_FOUND");
  });
});

// ===========================================================================
// 6. DB Adapter Error Fallback — should PASS
// ===========================================================================

describe("thai_history_tool: resilience", () => {
  test("DB error triggers fallback to stub data", async () => {
    const throwingAdapter: HistoryDbAdapter = {
      async search(): Promise<any[]> {
        throw new Error("simulated db error");
      },
    };

    setHistoryDb(throwingAdapter);

    try {
      const result = await thaiHistoryTool.execute({ query: "สุโขทัย" });
      const body = parseToolText(result);

      assert.equal(body.success, true, "should succeed via fallback");
      assert.ok(typeof body.note === "string");
      assert.ok(body.note.includes("fallback"), `note should mention fallback, got: ${body.note}`);
    } finally {
      // Restore InMemory adapter for remaining tests
      setHistoryDb(new InMemoryHistoryDb(THAI_HISTORY_SEED));
    }
  });

  test("response latency < 500ms for static lookup", async () => {
    const start = performance.now();
    await thaiHistoryTool.execute({ query: "อยุธยา" });
    const elapsed = performance.now() - start;

    assert.ok(elapsed < 500, `lookup took ${elapsed.toFixed(0)}ms, should be < 500ms`);
  });
});
