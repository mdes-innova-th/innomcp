import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { thaiLawTool } from '../../src/mcp/tools/thaiLawTool';
import { LawType, LawStatus } from '../../src/mcp/knowledge/types/law';

describe('Thai Law Tool (Contract)', () => {
    
    it('should have correct name and description', () => {
        assert.equal(thaiLawTool.name, 'thai_law_tool');
        assert.ok(thaiLawTool.description.includes('Royal Gazette'));
    });

    it('should validate input schema (Zod)', () => {
        const valid = thaiLawTool.inputSchema.safeParse({
            query: "มาตรา 112",
            type: "section_lookup"
        });
        assert.ok(valid.success);
    });

    it('should fail invalid input schema', () => {
        const invalid = thaiLawTool.inputSchema.safeParse({
             query: 123 // number not string
        });
        assert.ok(!invalid.success);
    });
    
    it('should return real response (Round C)', async () => {
        const result = await thaiLawTool.execute({ query: "คอมพิวเตอร์" });
        assert.ok(!result.content[0].text.includes("[STUB]"));
        assert.ok(result.content[0].text.includes("พ.ร.บ. คอมฯ"));
    });

    it('should support Section Lookup (Round C)', async () => {
        const result = await thaiLawTool.execute({ query: "112", type: "section_lookup" });
        assert.ok(result.content[0].text.includes("ความผิดต่อองค์พระมหากษัตริย์"));
    });
});
