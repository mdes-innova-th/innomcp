import { describe, test, expect } from "@jest/globals";
import qrCodeTool from "../src/mcp/tools/qrCodeTool";

describe("qrCodeTool", () => {
  
  test("should generate QR code for URL", async () => {
    const result = await qrCodeTool.execute({
      text: "https://innomcp.com",
      size: 300,
      errorCorrectionLevel: "M"
    });

    expect(result.success).toBe(true);
    expect(result.text).toBe("https://innomcp.com");
    expect(result.qrCodeImage).toContain("data:image/png;base64,");
    expect(result.size).toBe(300);
    expect(result.errorCorrectionLevel).toBe("M");
    expect(result.format).toBe("PNG (Base64)");
  });

  test("should generate QR code for Thai text", async () => {
    const result = await qrCodeTool.execute({
      text: "สวัสดีครับ",
      size: 200
    });

    expect(result.success).toBe(true);
    expect(result.text).toBe("สวัสดีครับ");
    expect(result.qrCodeImage).toContain("data:image/png;base64,");
    expect(result.size).toBe(200);
  });

  test("should handle empty text", async () => {
    const result = await qrCodeTool.execute({
      text: "",
      size: 300
    });

    expect(result.success).toBe(false);
    expect(result.error).toContain("กรุณาระบุข้อความ");
  });

  test("should handle whitespace-only text", async () => {
    const result = await qrCodeTool.execute({
      text: "   ",
      size: 300
    });

    expect(result.success).toBe(false);
    expect(result.error).toContain("กรุณาระบุข้อความ");
  });

  test("should generate QR code with custom size", async () => {
    const result = await qrCodeTool.execute({
      text: "Test QR Code",
      size: 500
    });

    expect(result.success).toBe(true);
    expect(result.size).toBe(500);
  });

  test("should limit size to max 1000", async () => {
    const result = await qrCodeTool.execute({
      text: "Large QR",
      size: 5000 // Over limit
    });

    expect(result.success).toBe(true);
    expect(result.size).toBe(1000); // Clamped to max
  });

  test("should limit size to min 100", async () => {
    const result = await qrCodeTool.execute({
      text: "Small QR",
      size: 50 // Under limit
    });

    expect(result.success).toBe(true);
    expect(result.size).toBe(100); // Clamped to min
  });

  test("should use default size 300 when not specified", async () => {
    const result = await qrCodeTool.execute({
      text: "Default size test"
    });

    expect(result.success).toBe(true);
    expect(result.size).toBe(300);
  });

  test("should handle different error correction levels", async () => {
    const levels: Array<"L" | "M" | "Q" | "H"> = ["L", "M", "Q", "H"];
    
    for (const level of levels) {
      const result = await qrCodeTool.execute({
        text: `Test ${level}`,
        errorCorrectionLevel: level
      });

      expect(result.success).toBe(true);
      expect(result.errorCorrectionLevel).toBe(level);
    }
  });

  test("should generate QR code for phone number", async () => {
    const result = await qrCodeTool.execute({
      text: "tel:0812345678",
      size: 300
    });

    expect(result.success).toBe(true);
    expect(result.text).toBe("tel:0812345678");
  });

  test("should generate QR code for email", async () => {
    const result = await qrCodeTool.execute({
      text: "mailto:test@example.com",
      size: 300
    });

    expect(result.success).toBe(true);
    expect(result.text).toBe("mailto:test@example.com");
  });

  test("should handle very long text (up to 4000 chars)", async () => {
    const longText = "A".repeat(4000);
    const result = await qrCodeTool.execute({
      text: longText,
      size: 500
    });

    expect(result.success).toBe(true);
    expect(result.text.length).toBe(4000);
  });

  test("should reject text longer than 4000 chars", async () => {
    const tooLongText = "A".repeat(4001);
    const result = await qrCodeTool.execute({
      text: tooLongText,
      size: 300
    });

    expect(result.success).toBe(false);
    expect(result.error).toContain("ยาวเกินไป");
  });
});
