import { describe, test, expect } from "@jest/globals";
import translationTool from "../src/mcp/tools/translationTool";

describe("translationTool", () => {
  
  test("should translate Thai to English", async () => {
    const result = await translationTool.execute({
      text: "สวัสดี",
      sourceLang: "th",
      targetLang: "en"
    });

    // May use API or fallback
    expect(result.originalText).toBe("สวัสดี");
    expect(result.sourceLang).toBe("th");
    expect(result.targetLang).toBe("en");
    
    if (result.success) {
      expect(result.translatedText.toLowerCase()).toContain("hello");
    } else {
      // Fallback dictionary
      expect(result.translatedText).toBe("Hello");
    }
  }, 15000);

  test("should translate English to Thai", async () => {
    const result = await translationTool.execute({
      text: "hello",
      sourceLang: "en",
      targetLang: "th"
    });

    expect(result.originalText).toBe("hello");
    expect(result.sourceLang).toBe("en");
    expect(result.targetLang).toBe("th");
    
    if (result.success) {
      expect(result.translatedText).toContain("สวัสดี");
    } else {
      // Fallback
      expect(result.translatedText).toBe("สวัสดี");
    }
  }, 15000);

  test("should handle empty text", async () => {
    const result = await translationTool.execute({
      text: "",
      sourceLang: "en",
      targetLang: "th"
    });

    expect(result.success).toBe(false);
    expect(result.error).toContain("กรุณาระบุข้อความ");
  });

  test("should handle whitespace-only text", async () => {
    const result = await translationTool.execute({
      text: "   ",
      sourceLang: "en",
      targetLang: "th"
    });

    expect(result.success).toBe(false);
    expect(result.error).toContain("กรุณาระบุข้อความ");
  });

  test("should handle unsupported source language", async () => {
    const result = await translationTool.execute({
      text: "test",
      sourceLang: "xyz", // Invalid
      targetLang: "en"
    });

    expect(result.success).toBe(false);
    expect(result.error).toContain("ไม่รองรับภาษา");
  }, 15000);

  test("should handle unsupported target language", async () => {
    const result = await translationTool.execute({
      text: "test",
      sourceLang: "en",
      targetLang: "xyz" // Invalid
    });

    expect(result.success).toBe(false);
    expect(result.error).toContain("ไม่รองรับภาษา");
  });

  test("should normalize language codes to lowercase", async () => {
    const result = await translationTool.execute({
      text: "test",
      sourceLang: "EN", // Uppercase
      targetLang: "TH"
    });

    expect(result.sourceLang).toBe("en");
    expect(result.targetLang).toBe("th");
  }, 15000);

  test("should translate with auto language detection", async () => {
    const result = await translationTool.execute({
      text: "Bonjour", // French
      sourceLang: "auto",
      targetLang: "en"
    });

    expect(result.sourceLang).toBe("auto");
    expect(result.targetLang).toBe("en");
    
    if (result.success && result.detectedLang) {
      expect(result.detectedLang).toBe("fr");
    }
  }, 15000);

  test("should handle text up to 5000 characters", async () => {
    const longText = "A".repeat(5000);
    const result = await translationTool.execute({
      text: longText,
      sourceLang: "en",
      targetLang: "th"
    });

    // Should not fail due to length
    expect(result.originalText.length).toBe(5000);
  }, 15000);

  test("should reject text longer than 5000 characters", async () => {
    const tooLongText = "A".repeat(5001);
    const result = await translationTool.execute({
      text: tooLongText,
      sourceLang: "en",
      targetLang: "th"
    });

    expect(result.success).toBe(false);
    expect(result.error).toContain("ยาวเกินไป");
  });

  test("should use fallback dictionary when API fails", async () => {
    // Force API failure by using invalid source lang
    const result = await translationTool.execute({
      text: "สวัสดี",
      sourceLang: "th",
      targetLang: "en"
    });

    // If API works: success=true
    // If API fails: fallback to dictionary
    expect(result.originalText).toBe("สวัสดี");
    expect(result.translatedText).toBeDefined();
  }, 15000);
});
