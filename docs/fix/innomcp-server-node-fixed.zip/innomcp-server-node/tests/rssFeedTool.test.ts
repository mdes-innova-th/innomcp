import { describe, test, expect } from "@jest/globals";
import rssFeedTool from "../src/mcp/tools/rssFeedTool";

describe("rssFeedTool", () => {
  
  test("should read BBC News feed", async () => {
    const result = await rssFeedTool.execute({
      feedUrl: "bbc",
      limit: 5
    });

    expect(result.success).toBe(true);
    expect(result.feedTitle).toBeDefined();
    expect(result.feedUrl).toContain("bbci.co.uk");
    expect(result.items).toHaveLength(5);
    expect(result.totalItems).toBe(5);
    
    // Check first item structure
    const firstItem = result.items[0];
    expect(firstItem.title).toBeDefined();
    expect(firstItem.link).toContain("http");
  }, 15000);

  test("should read TechCrunch feed", async () => {
    const result = await rssFeedTool.execute({
      feedUrl: "techcrunch",
      limit: 3
    });

    expect(result.success).toBe(true);
    expect(result.feedTitle).toContain("TechCrunch");
    expect(result.items.length).toBeLessThanOrEqual(3);
  }, 15000);

  test("should read Hacker News feed", async () => {
    const result = await rssFeedTool.execute({
      feedUrl: "hackernews",
      limit: 5
    });

    expect(result.success).toBe(true);
    expect(result.feedUrl).toContain("hnrss.org");
    expect(result.items.length).toBeLessThanOrEqual(5);
  }, 15000);

  test("should handle custom RSS URL", async () => {
    const result = await rssFeedTool.execute({
      feedUrl: "http://feeds.bbci.co.uk/news/rss.xml",
      limit: 5
    });

    expect(result.success).toBe(true);
    expect(result.items.length).toBeGreaterThan(0);
  }, 15000);

  test("should handle invalid URL (no protocol)", async () => {
    const result = await rssFeedTool.execute({
      feedUrl: "invalid-url",
      limit: 5
    });

    expect(result.success).toBe(false);
    expect(result.error).toContain("URL ไม่ถูกต้อง");
  });

  test("should handle unreachable feed", async () => {
    const result = await rssFeedTool.execute({
      feedUrl: "https://nonexistent-feed-12345.com/rss",
      limit: 5
    });

    expect(result.success).toBe(false);
    expect(result.items).toHaveLength(0);
    expect(result.totalItems).toBe(0);
  }, 15000);

  test("should limit items to max 20", async () => {
    const result = await rssFeedTool.execute({
      feedUrl: "bbc",
      limit: 100 // Over limit
    });

    if (result.success) {
      expect(result.items.length).toBeLessThanOrEqual(20);
    }
  }, 15000);

  test("should limit items to min 1", async () => {
    const result = await rssFeedTool.execute({
      feedUrl: "bbc",
      limit: 0 // Under limit
    });

    if (result.success) {
      expect(result.items.length).toBeGreaterThanOrEqual(1);
    }
  }, 15000);

  test("should use default limit 5 when not specified", async () => {
    const result = await rssFeedTool.execute({
      feedUrl: "bbc"
    });

    if (result.success) {
      expect(result.items.length).toBeLessThanOrEqual(5);
    }
  }, 15000);

  test("should extract item fields correctly", async () => {
    const result = await rssFeedTool.execute({
      feedUrl: "bbc",
      limit: 1
    });

    if (result.success && result.items.length > 0) {
      const item = result.items[0];
      
      expect(item.title).toBeDefined();
      expect(item.title).not.toBe("");
      expect(item.link).toBeDefined();
      expect(item.link).toContain("http");
      
      // Optional fields
      if (item.pubDate) {
        expect(typeof item.pubDate).toBe("string");
      }
      if (item.description) {
        expect(typeof item.description).toBe("string");
      }
    }
  }, 15000);

  test("should handle feeds with different formats (Atom vs RSS)", async () => {
    const result = await rssFeedTool.execute({
      feedUrl: "github", // GitHub uses Atom
      limit: 3
    });

    if (result.success) {
      expect(result.items.length).toBeGreaterThan(0);
      expect(result.items[0].title).toBeDefined();
    }
  }, 15000);

  test("should normalize preset names (case insensitive)", async () => {
    const result = await rssFeedTool.execute({
      feedUrl: "BBC", // Uppercase
      limit: 5
    });

    if (result.success) {
      expect(result.feedUrl).toContain("bbci.co.uk");
    }
  }, 15000);
});
