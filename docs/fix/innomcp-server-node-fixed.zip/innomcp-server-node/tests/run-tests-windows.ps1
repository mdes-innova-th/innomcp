# INNOMCP MCP Server Tool Tests - Windows Runner
# This script runs MCP tool tests from Windows to avoid WSL connectivity issues

param(
    [switch]$Verbose = $false
)

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  INNOMCP MCP SERVER TOOL TESTS" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Check if MCP server is running
$defaultPort = 3012
$envFile = Join-Path (Split-Path -Parent $MyInvocation.MyCommand.Path) "..\.env"
$port = $defaultPort
if (Test-Path $envFile) {
    $line = Get-Content $envFile -ErrorAction SilentlyContinue | Where-Object { $_ -match '^\s*SERVER_PORT\s*=\s*\d+\s*$' } | Select-Object -First 1
    if ($line) {
        $parts = $line -split '=', 2
        if ($parts.Length -eq 2) {
            $candidate = 0
            if ([int]::TryParse($parts[1].Trim(), [ref]$candidate) -and $candidate -ge 1 -and $candidate -le 65535) {
                $port = $candidate
            }
        }
    }
}

$mcpServerUrl = "http://localhost:$port/mcp"
Write-Host "[INFO] Checking MCP server at $mcpServerUrl..." -ForegroundColor Yellow

try {
    $testRequest = @{
        jsonrpc = "2.0"
        method  = "tools/list"
        id      = 1
    } | ConvertTo-Json -Compress

    $response = Invoke-RestMethod -Uri $mcpServerUrl -Method POST `
        -Headers @{
            "Content-Type" = "application/json"
            "Accept"       = "application/json, text/event-stream"
        } `
        -Body $testRequest `
        -TimeoutSec 5 `
        -ErrorAction Stop

    if ($response.result.tools) {
        $toolCount = $response.result.tools.Count
        Write-Host "[OK] MCP server is running with $toolCount tools" -ForegroundColor Green
    } else {
        Write-Host "[ERROR] MCP server returned unexpected response" -ForegroundColor Red
        exit 1
    }
} catch {
    Write-Host "[ERROR] Cannot connect to MCP server!" -ForegroundColor Red
    Write-Host "        Make sure innomcp-server-node is running on port $port" -ForegroundColor Red
    Write-Host "        Error: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

Write-Host ""
Write-Host "[INFO] Running ts-node tool tests..." -ForegroundColor Yellow
Write-Host ""

# Navigate to server directory
Set-Location "C:\Users\USER-NT\DEV\innomcp\innomcp-server-node"

# Run tests
& npx ts-node tests\test-all-tools.ts

$exitCode = $LASTEXITCODE

Write-Host ""
if ($exitCode -eq 0) {
    Write-Host "========================================" -ForegroundColor Green
    Write-Host "  ALL TESTS PASSED" -ForegroundColor Green
    Write-Host "========================================" -ForegroundColor Green
} else {
    Write-Host "========================================" -ForegroundColor Red
    Write-Host "  SOME TESTS FAILED" -ForegroundColor Red
    Write-Host "========================================" -ForegroundColor Red
}

exit $exitCode
